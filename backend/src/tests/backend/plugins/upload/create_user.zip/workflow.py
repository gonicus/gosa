prename = data["pn"].lower()
surname = data["sn"].lower()

test = dict(cn="%s %s" % (data["pn"], data["sn"]), uid="%s_%s" % (prename, surname), mail="%s.%s@eyjafjallajökull.is" % (prename, surname))

print("---------------------------------------------")
print(test)
print(getWorkflows())
print("---------------------------------------------")
